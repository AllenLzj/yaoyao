<template>
  <div id="app">
    <!--<img src="./assets/logo.png">-->
    <router-view/>

  </div>
</template>

<script>
  export default {
    name: 'App',
    data(){
      return {

      }
    },
    methods:{

    }
  }
</script>

<style>
  @import "./style.css";
  /*@import "./common/font/font.css";*/
  body {
    color: #3C3C3C;
    -webkit-font-smoothing: antialiased;
    background-color: #f4f4f4;
  }
  body, html {
    overflow-x: hidden;
    /*font-size: calc(100vw/3.75);*/
    /*font-size: 26.666667vw;*/
  }
  /*html,body {*/
  /*font-size: 26.66666667vw ;*/
  /*}*/
  body, button, input, select, textarea {
    /*font: 0.12rem/1.5 tahoma,arial,'Hiragino Sans GB','\5b8b\4f53',sans-serif;*/
  }
  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    /*margin-top: 1rem;*/
  }


</style>
