<template>
  <div>
    <div class="container">
      <input type="text" class="sear" placeholder="请输入你要搜索的关键词" v-model="search">
      <div class="search" @click="sear"></div>
    </div>
    <div class="center">
      <img src="../../static/img/wait.png" alt="">
      <span>等你加入</span>
    </div>
    <div class="bottom" v-for="li in list">
      <div class="b_top">
        <div class="b_left">
          <img :src=$store.state.url+li.path alt="" @click="detail(li)">
          <div>{{li.name}}</div>
        </div>
        <div class="b_right">
          <div>
            信息：{{li.title}}
          </div>
          <div>
            地点：{{li.site}}
          </div>
          <div>
            时间：{{li.time}}
          </div>
          <div>
            附加说明：{{li.info}}
          </div>
        </div>
      </div>
      <div class="b_bottom">
        <span>【已参与{{li.num_data}}】</span>
        <!--<span>详情</span>-->
        <span @click="join(li.id)">【点击参与】</span>
      </div>
    </div>
    <div style="min-height: 0.28rem;" class="qing">
      <div class="css" v-show="meaning">{{mean}}</div>
    </div>
    <div class="mask" v-show="show" @click="can">
      <div class="chu">
        <div class="topp"><img src="../../static/img/jia.png" alt="" v-show="show1" @click="tianjia"></div>
        <div class="imgg"><img :src=$store.state.url+text.path alt=""></div>
        <div class="con"><span>{{text.name}}</span></div>

      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "active",
    data() {
      return {
        list: [],
        meaning: false,
        mean: "1111111111111",
        search: "",
        text: {},
        show: false,
        show1: false
      }
    },
    mounted() {

      this.fun()
      var first = null;
      if (api.deviceId) {
        api.addEventListener({
          name: 'keyback'
        }, (res, err) => {
          if (!first) {
            first = new Date().getTime();//记录第一次按下回退键的时间
            api.toast({
              msg: '再点一次退出应用',
              duration: 2000,
              location: 'bottom'
            });
            // history.go(-1)//回退到上一页面
            setTimeout(function () {//1s中后清除
              first = null;
            }, 1000);
          } else {
            if (new Date().getTime() - first < 2000) {//如果两次按下的时间小于1s，
              api.closeWidget({
                silent: true
              });
            }
          }
        });
      }
    },
    methods: {
      tianjia() {
        this.$http.get(this.$store.state.url + "/v1/friend_add", {
          params: {
            user_id: this.$cookieStore.getCookie("user_id"),
            friend_user_id: this.text.user_id
          }
        }).then(res => {
          console.log(res)
          if (res.data.code == 200) {
            this.show = false
            this.show1 = false
            this.meaning = true
            this.mean = "添加好友成功"
            setTimeout(() => {
              this.meaning = false
            }, 1500)
          }

        })
      },
      can(e) {
        console.log(e.target.className)
        if (e.target.className == "mask") {
          this.show = false
          this.show1 = false
        }
      },
      detail(li) {
        this.text = li
        this.$http.get(this.$store.state.url + "/v1/friend_is", {
          params: {
            user_id: this.$cookieStore.getCookie("user_id"),
            friend_user_id: li.user_id
          }
        }).then(res => {
          console.log(res)

          this.show = true
          if (res.data.data.is_friend == 0) {
            this.show1 = true
          }
        })
      },
      fun() {
        this.$http.get(this.$store.state.url + "/v1/invitation_list", {
          params: {
            type: 3,
            search: this.search
          }
        }).then(res => {
          console.log(res)
          this.list = res.data.data
          console.log(this.list)
        })
      },
      sear() {
        this.fun()
      },
      join(id) {
        if (this.$cookieStore.getCookie("user_id")) {
          this.$http.get(this.$store.state.url + "/v1/join_invitation", {
            params: {
              user_id: this.$cookieStore.getCookie("user_id"),
              invitation_id: id
            }
          }).then(res => {
            console.log(res)
            if (res.data.code == 200) {
              this.meaning = true
              this.mean = "参与成功"
              this.fun()
            } else {
              this.meaning = true
              this.mean = res.data.message
            }
            setTimeout(() => {
              this.meaning = false
            }, 1500)
          })
        } else {
          this.meaning = true
          this.mean = "请登录"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }

      },

    }
  }
</script>

<style scoped>
  .sear {
    width: 92%;
    border-radius: .05rem;
    padding: .05rem;
    border: 1px solid lightgrey;
  }

  .search {
    background-image: url("../../static/img/sear.png");
    background-size: 100% 100%;
    position: absolute;
    width: .2rem;
    height: .2rem;
    top: .04rem;
    right: 5%;
    z-index: 99;
  }

  .container {
    position: relative;
    margin-top: .1rem;
  }

  .center {
    font-size: .16rem;
    text-align: left;
    margin-left: 5%;
    margin-top: .1rem;
  }

  .center img {
    width: .25rem;
    vertical-align: middle;
  }

  .bottom {
    width: 92%;
    margin: .05rem auto 0;
    border-top: .02rem solid #8B8378;
    padding-top: .1rem;

  }

  .b_top {
    display: flex;
    justify-content: left;
  }

  .b_left img {
    width: .5rem;
    border-radius: .25rem;
  }

  .b_right {
    margin-left: .2rem;
    text-align: left;
  }

  .b_bottom {
    display: flex;
    justify-content: space-between;
    padding: .1rem 0;
  }

  .b_bottom span:nth-child(2) {
    color: blue;
  }

  .css {
    margin: .08rem auto 0;
    border: .01rem solid #EAEAEA;
    border-radius: .06rem;
    text-align: center;
    width: 70%;
    min-height: 0.18rem;
    font-family: PingFangSC-Regular;
    font-size: 0.14rem;
    /*color: #666;*/
    background: white;
    color: red;
    letter-spacing: 0;
    padding: .1rem;
    position: fixed;
    top: 2.8rem;
    left: 15%;
    /*margin-top: -0.27rem;*/
  }

  .mask {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0);
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1111;
  }

  .chu {
    width: 60%;
    margin-left: 20%;
    background: white;
    margin-top: 2rem;
    border-radius: .1rem;
    padding-top: .1rem;
    padding-bottom: .1rem;
  }

  .imgg img {
    width: .6rem;
    border-radius: .02rem;
  }

  .con {
    margin: .1rem;
  }

  .topp img {
    width: .2rem;
    /*vertical-align: middle;*/
    /*margin-left: .1rem;*/

  }

  .topp {
    text-align: right;
    margin-right: .2rem;
  }
</style>
