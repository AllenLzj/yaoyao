<template>
  <div class="my_join">
    <div class="top">
      <img src="../../static/img/icon_fanhui_daohang@2x.png" alt="" @click="back">
      <span>{{list.title}}</span>
    </div>
    <div class="content">
      {{list.info}}
    </div>
    <div class="zan" v-show="gao">
      <img src="../../static/img/weiz.png" alt="" v-show="!show" @click="dianzan">
      <img src="../../static/img/yzan.png" alt="" v-show="show" @click="dianzan">
      <span>{{list.like_num}}</span>
    </div>
    <div class="comments" v-show="gao">
      <div class="liu">
        <span>评论</span>
        <span @click="pinglun">写评论</span>
      </div>
      <div class="comment">

        <div v-for="li in list.comment" class="com">
          <div>
            <img :src=url+li.path alt="">
          </div>
          <div class="c_right">
            <div>{{li.name}}</div>
            <div>{{li.content}}</div>
          </div>

        </div>
      </div>
    </div>
    <div class="mask" v-show="mask">
      <div class="chacha"><img src="../../static/img/icon_chacha.png" alt="" @click="cha"></div>
      <div class="ping">

        <textarea name="" id="" cols="30" rows="10" v-model="info"></textarea>

      </div>
      <div class="bttn" @click="sub">评论</div>
    </div>
    <div style="min-height: 0.28rem;" class="qing">
      <div class="css" v-show="meaning">{{mean}}</div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "my_join",
    data() {
      return {
        sex: 1,
        name: "",
        list: {},
        show: false,
        mask: false,
        info: "",
        meaning: false,
        mean: "评论不能为空",
        url: this.$store.state.url,
        gao: false,
        type:this.$route.query.ty
      }
    },
    mounted() {
      console.log(this.$route.query.li)
      this.mou(this.$route.query.li)
      var thats = this
      if (api.deviceId) {
        api.addEventListener({
          name: 'keyback'
        }, function (ret, err) {
          thats.$router.go(-1)
        })
      }

    },
    methods: {
      mou(id) {
        this.$http.get(this.$store.state.url + "/v1/article_index", {
          params: {
            type: this.type,
            user_id: this.$cookieStore.getCookie("user_id")
          }
        }).then(res => {
          console.log(res)
          if (this.$route.query.type == 1) {
            for (var i in res.data.data.announcement) {
              console.log(id)
              console.log(res.data.data.announcement[i].id)
              if (res.data.data.announcement[i].id == id) {
                this.list = res.data.data.announcement[i]
              }
            }
          }else{
            this.gao = true
            for (var i in res.data.data.article) {
              console.log(id)
              console.log(res.data.data.article[i].id)
              if (res.data.data.article[i].id == id) {
                this.list = res.data.data.article[i]
              }
            }
          }


          console.log(this.list)
          if (this.list.is_like == 1) {
            this.show = true
          } else {
            this.show = false
          }
        })
      },
      back() {
        this.$router.go(-1)
      },
      cha() {
        this.mask = false
      },
      sub() {
        if (this.info != "") {
          this.$http.get(this.$store.state.url + "/v1/article_comment/" + this.list.id, {
            params: {
              user_id: this.$cookieStore.getCookie("user_id"),
              article_id: this.list.id,
              comment: this.info
            }
          }).then(res => {
            console.log(res)
            // this.show = !this.show
            this.mask = false
            this.mou(this.$route.query.li)
          })
        } else {
          this.meaning = true
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }

      },
      pinglun() {
        this.mask = true
      },
      dianzan() {


        this.$http.get(this.$store.state.url + "/v1/article_like/" + this.list.id, {
          params: {
            user_id: this.$cookieStore.getCookie("user_id"),
            article_id: this.list.id
          }
        }).then(res => {
          console.log(res)
          this.show = !this.show
          if (this.list.is_like == 0) {
            this.list.like_num++
            this.list.is_like = 1
          } else {
            this.list.like_num--
            this.list.is_like = 0
          }
        })

      }
    }
  }
</script>

<style scoped>
  .my_join {
    padding-top: .6rem;
    background: #EEE9E9;
    min-height: 100vh;
    box-sizing: border-box;
  }

  .top {
    height: .5rem;
    width: 100%;
    background: #00B2F0;
    line-height: .5rem;
    color: white;
    font-size: .16rem;
    font-weight: 700;
    position: fixed;
    top: 0;
    left: 0;
  }

  .top img {
    width: .1rem;
    position: absolute;
    top: 30%;
    left: .2rem;
  }

  .content {
    text-align: left;
    text-indent: 2em;
    padding: 0 .1rem;
    background: white;
    min-height: 3rem;
  }

  .zan img {
    width: .2rem;
    vertical-align: -.04rem;
  }

  .zan {
    text-align: left;
    padding-left: .2rem;
    /*margin-top: .1rem;*/
    background: white;
    padding-bottom: .1rem;
  }

  .comments {
    text-align: left;
    margin-left: .1rem;
    margin-top: .1rem;
    font-size: .16rem;
  }

  .comment {
    /*margin-left: .2rem;*/
    font-size: .14rem;
  }

  .com {
    margin-top: .2rem;
    display: flex;
    justify-content: left;
  }

  .com img {
    width: .5rem;
  }

  .c_right {
    margin-top: .1rem;
    margin-left: .1rem;
  }

  .liu span:nth-child(2) {
    margin-left: 2.7rem;
    color: #1296db;
  }

  .mask {
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.2);
    position: fixed;
    left: 0;
    top: 0;
  }

  .ping {
    width: 80%;
    background: white;
    margin-left: 10%;
    margin-top: .1rem;
    border-radius: .1rem;
  }

  .ping textarea {
    width: 100%;
    border: none;
    outline: none;
    padding: .1rem;
    box-sizing: border-box;
    border-radius: .1rem;
  }

  .bttn {
    font-size: .16rem;
    width: 80%;
    margin: .2rem 10% 0;
    background: #1296db;
    line-height: .4rem;
    color: white;
    border-radius: .03rem;
  }

  .chacha {
    margin-top: 1.8rem;
    text-align: right;
    margin-right: .3rem;
  }

  .css {
    margin: .08rem auto 0;
    border: .01rem solid #EAEAEA;
    border-radius: .06rem;
    text-align: center;
    width: 70%;
    min-height: 0.18rem;
    font-family: PingFangSC-Regular;
    font-size: 0.14rem;
    /*color: #666;*/
    background: white;
    color: red;
    letter-spacing: 0;
    padding: .1rem;
    position: fixed;
    top: 5rem;
    left: 15%;
    z-index: 111;
    /*margin-top: -0.27rem;*/
  }
</style>

