<template>
  <div class="edit">
    <div class="top">
      <img src="../../static/img/icon_fanhui_daohang@2x.png" alt="" @click="back">
      <span>修改资料</span>

    </div>
    <div class="content">
      <div class="hang" >
        <div>头像</div>
        <div @click="tu">
          <img :src=url alt="">
        </div>
      </div>
      <div class="hang1">
        <div>姓名</div>
        <div>
          <input type="text" v-model="name">
        </div>
      </div>
      <div class="hang1">
        <div>性别</div>
        <div>
          <input type="radio" id="nan" name="sex" v-model="sex" value="1">
          <label for="nan">男</label>
          <input type="radio" id="nv" name="sex" v-model="sex" value="2">
          <label for="nv">女</label>
        </div>
      </div>
    </div>
    <div class="btn" @click="save">
      保存
    </div>
  </div>
</template>

<script>
  export default {
    name: "edit",
    data() {
      return {
        sex: 1,
        name: "",
        list: {},
        url:""
      }
    },
    mounted() {
      this.$http.get(this.$store.state.url+"/v1/getPersonalData", {params: {user_id: this.$cookieStore.getCookie("user_id")}}).then(res => {
        console.log(res.data)
        this.list = res.data.data
        this.sex = res.data.data.sex
        this.name = res.data.data.name
        this.url=this.$store.state.url+res.data.data.icon_path
      })
      var thats=this
      if(api.deviceId){
        api.addEventListener({
          name: 'keyback'
        }, function(ret, err) {
          thats.$router.go(-1)
        })}
    },
    methods: {
      tu(){
        this.$router.push("/profile_picture")
      },
      back() {
        this.$router.go(-1)
      },
      save(){
        if(this.name!=""){
          this.$http.get(this.$store.state.url+"/v1/user_save", {params: {id: this.$cookieStore.getCookie("user_id"),name:this.name,sex:this.sex}}).then(res => {
            console.log(res.data)
            this.$router.push("/self")
            // this.$http.get("http://192.168.9.147/v1/user_save", {params: {id: this.$cookieStore.getCookie("user_id"),name:this.name,sex:this.sex}}).then(res => {
            //   console.log(res.data)
            //
            //
            // })

          })
        }

      }
    }
  }
</script>

<style scoped>
  .top {
    height: .5rem;
    width: 100%;
    background: #00B2F0;
    line-height: .5rem;
    color: white;
    font-size: .16rem;
    font-weight: 700;
    position: fixed;
    top: 0;
    left: 0;
  }

  .top img {
    width: .1rem;
    position: absolute;
    top: 30%;
    left: .2rem;
  }

  .content {
    margin-top: .5rem;
    color: #d8d8d8;
  }

  .hang {
    display: flex;
    justify-content: space-between;
    padding: .15rem;
    border-bottom: 1px solid #d8d8d8;
    /*position: relative;*/
    font-size: .15rem;
  }

  .hang1 {
    display: flex;
    font-size: .15rem;
    justify-content: space-between;
    padding: .15rem;
    border-bottom: 1px solid #d8d8d8;
    /*position: relative;*/
  }

  .hang1 input {
    text-align: right;
    border: none;
    outline: none;
    background: #f4f4f4;
  }

  .hang img {
    width: .8rem;
    height: .8rem;
  }

  .hang > div:nth-child(1) {
    margin-left: .1rem;
    font-weight: 700;
    text-align: left;
    line-height: .8rem;
    /*margin-top: .1rem;*/
  }

  .hang1 > div:nth-child(1) {
    margin-left: .1rem;
    font-weight: 700;
    text-align: left;
    /*line-height: .6rem;*/
    /*margin-top: .1rem;*/
  }

  .btn {
    width: 55%;
    height: .5rem;
    color: white;
    background: #00b2f0;
    line-height: .5rem;
    margin-left: 22.5%;
    margin-top: .5rem;
    border-radius: .05rem;
  }

</style>

