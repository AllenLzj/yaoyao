<template>
  <div class="friend">
    <div class="top">
      好友列表
    </div>
    <div class="content">
      <div class="hang" v-for="(li,i) in list" @touchstart="start" @touchmove="move" @touchend="end(i)">
        <img :src=$store.state.url+li.path alt="">
        <div>
          <div class="con">
            {{li.name}}
            <i v-show="li.sex==1"><img src="../../static/img/icon_nan@2x.png" alt="" style="width: .11rem"></i>
            <i v-show="li.sex==2"><img src="../../static/img/icon_nv@2x.png" alt="" style="width: .11rem"></i>
          </div>
          <div>
            这个人很懒！什么也没有留下。
          </div>
        </div>
        <img src="../../static/img/icon_chacha.png" alt="" class="pic" v-show="li.show" @click="del(i)">
        <!--<div class="tixing"><img src="../../static/img/xing.png" alt="">有新邀请</div>-->

      </div>
    </div>

    <div class="del" v-show="show">
      <div class="d_top">
        确定要删除该好友吗
      </div>
      <div class="d_bot">
        <div @click="cancel">取消</div>
        <div @click="sure">确定</div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "friend",
    data() {
      return {
        list: [],
        timer: null,
        time: 0,
        show: false,
        i:0
      }
    },
    mounted() {


      this.$http.get(this.$store.state.url + "/v1/friend_list", {
        params: {
          user_id: this.$cookieStore.getCookie("user_id"),

        }
      }).then(res => {
        console.log(res)
        this.list = res.data.data
        for (var i in this.list) {
          this.list[i].show = false
        }
        console.log(this.list)
      })
      var first = null;
      if (api.deviceId) {
        api.addEventListener({
          name: 'keyback'
        }, (res, err) => {
          if (!first) {
            first = new Date().getTime();//记录第一次按下回退键的时间
            api.toast({
              msg: '再点一次退出应用',
              duration: 2000,
              location: 'bottom'
            });
            // history.go(-1)//回退到上一页面
            setTimeout(function () {//1s中后清除
              first = null;
            }, 1000);
          } else {
            if (new Date().getTime() - first < 2000) {//如果两次按下的时间小于1s，
              api.closeWidget({
                silent: true
              });
            }
          }
        });
      }
    },
    methods: {
      cancel() {
        this.show = false
      },
      sure() {
        this.$http.get(this.$store.state.url + "/v1/friend_del", {
          params: {
            user_id: this.$cookieStore.getCookie("user_id"),
            friend_user_id: this.list[this.i].id
          }
        }).then(res => {
          console.log(res)
         if (res.data.code=200){
            this.list.splice(this.i,1)
           this.show=false
         }
        })
      },
      del(i) {
        this.show = true
        this.i=i
      },
      start(e) {
        console.log('touchstart');
        var that = this
        this.time = 0
        this.timer = setTimeout(function () {
          console.log('LongPress');
          e.preventDefault();
          that.time = 1
        }, 800);
      },
      move() {
        clearTimeout(this.timer);
        this.time = 0;
      },
      end(i) {
        clearTimeout(this.timer);
        if (this.time == 1) {
          console.log(1111)
          this.list[i].show = true
          this.$forceUpdate()
          setTimeout(() => {
            this.list[i].show = false
            this.$forceUpdate()
          }, 3000)
        }
      }
    }
  }
</script>

<style scoped>
  .top {
    height: .5rem;
    width: 100%;
    background: #00B2F0;
    line-height: .5rem;
    color: white;
    font-size: .16rem;
    font-weight: 700;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 100;
  }

  .content {
    margin-top: .5rem;
  }

  .hang {
    display: flex;
    justify-content: left;
    padding: .15rem;
    position: relative;
  }

  .hang img {
    width: .6rem;
    height: .6rem;
  }

  .hang > div:nth-child(2) {
    margin-left: .1rem;
    font-weight: 700;
    text-align: left;
    margin-top: .1rem;
  }

  .hang > div > div:nth-child(2) {
    margin-top: .05rem;
    font-weight: 500;

  }

  .tixing {
    position: absolute;
    top: .2rem;
    right: 0.2rem;
    font-weight: 700;
  }

  .tixing img {
    width: .2rem;
    height: .2rem;
    vertical-align: -.05rem;

  }

  .con img {
    width: .1rem;
    height: .1rem;
    margin-left: .05rem;
  }

  .hang .pic {
    width: .3rem;
    height: .3rem;
    position: absolute;
    right: .2rem;
  }

  .del {
    position: fixed;
    top: 30%;
    left: 20%;
    width: 60%;
    background: white;
    padding-top: .2rem;

  }

  .d_top {
    color: red;
  }

  .d_bot {
    display: flex;
    justify-content: space-between;
    /*width: 50%;*/
    text-align: center;
    margin: .2rem 0 .1rem;
  }

  .d_bot div {
    width: 50%;
  }
</style>
