<template>
  <div class="index">
<!-- <div class="nav">
  <div class="top" @click="study">自习室</div>
  <div class="top" @click="run">体育运动</div>
  <div class="top" @click="active">社团活动</div>
  <div class="top" @click="free">课外休闲</div>
</div> -->
    <router-view></router-view>
     <div class="meau" v-show="hidshow">
      <div v-show="arr[0]">
        <img src="../../static/img/shouye.png" alt="">
        <div class="color1">首页</div>
      </div>
      <div v-show="!arr[0]" @click="cli(0)">
        <img src="../../static/img/shouye1.png" alt="">
        <div class="color2">首页</div>
      </div>
      <div v-show="arr[4]">
        <img src="../../static/img/wenzhang.png" alt="">
        <div class="color1">论坛</div>
      </div>
      <div v-show="!arr[4]" @click="cli(4)">
        <img src="../../static/img/wenzhang1.png" alt="">
        <div class="color2">论坛</div>
      </div>
      <div v-show="arr[1]">
        <img src="../../static/img/fabu.png" alt="">
        <div class="color1">发布</div>
      </div>
      <div v-show="!arr[1]" @click="cli(1)">
        <img src="../../static/img/fabu1.png" alt="">
        <div class="color2">发布</div>
      </div>
      <div v-show="arr[2]">
        <img src="../../static/img/haoyou.png" alt="">
        <div class="color1">好友</div>
      </div>
      <div v-show="!arr[2]" @click="cli(2)">
        <img src="../../static/img/haoyou1.png" alt="">
        <div class="color2">好友</div>
      </div>
      <div v-show="arr[3]">
        <img src="../../static/img/wode.png" alt="">
        <div class="color1">我的</div>
      </div>
      <div v-show="!arr[3]" @click="cli(3)">
        <img src="../../static/img/wode1.png" alt="">
        <div class="color2">我的</div>
      </div>
    </div>
  </div>
</template>

<script>
var top=document.getElementsByClassName("top")
export default {
  name: 'HelloWorld',
  data () {
    return {
      docmHeight: document.documentElement.clientHeight,  //默认屏幕高度
      showHeight: document.documentElement.clientHeight,   //实时屏幕高度
      hidshow:true
    }
  },
  mounted(){
    window.onresize = ()=>{
      return(()=>{
        this.showHeight = document.documentElement.clientHeight;
        console.log(this.showHeight)
        // alert(this.showHeight)
      })()
    }


  },
  methods:{
    cli(index){
        for (var i in this.arr){
          this.arr[i]=false
        }
        console.log(index);
        this.arr[index]=true
        if (index==0){
          this.$router.push({path:"/"})
        } else if (index==4){
          this.$router.push({name:"share"})
        } else if (index==1){
          this.$router.push({name:"release"})
        } else if (index==2){
          this.$router.push({name:"friend"})
        } else if (index==3){
          this.$router.push({name:"self"})
        }
        this.$forceUpdate()

      },
    study(){
      this.color_change(0)
      this.$router.push({name:"study"})
    },
    run(){
      this.color_change(1)
      this.$router.push({name:"run"})
    },
    active(){
      this.color_change(2)
    },
    free(){
     this.color_change(3)
    },
    color_change(index){
      for (var i=0;i<top.length;i++){
        top[i].style.color="#707070"
      }
      top[index].style.color="#7FFF00"
    }

  },
  computed:{
    arr(){
      return this.$store.state.arr
      console.log(111111111111)
    }
  },
  watch:{
    arr:function (val) {
      console.log(val)
    },
    showHeight() {
      if(this.docmHeight > this.showHeight){
        this.hidshow=false
      }else{
        this.hidshow=true
      }
    },
    deep: true
  },

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .meau {
    position: fixed;
    left: 0;
    bottom: 0;
    display: flex;
    justify-content: left;
    width: 100%;
    background: white;
    padding:.05rem 0 .02rem;
  }

  .meau > div {
    width: 25%;
    box-sizing: border-box;

  }
  .meau > div img{
    width: .24rem;
  }
  .color1{
    color: #1296db;
  }
  .color2{
    color: #707070;
  }
.index{
  width: 100%;
  /*min-height: 6.75rem;*/
  background: #E0FFFF;

}
  .nav{
    display: flex;
    justify-content: left;
    background: white;
    padding: .15rem 0;
  }
  .nav div{
    width: 25%;
    box-sizing: border-box;
    font-size: 0.15rem;
    font-weight: 800;

  }
  .top:nth-child(1){
    color: #7FFF00;
  }
</style>
