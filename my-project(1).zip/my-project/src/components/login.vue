<template>
  <div class="login">
    <!--1111111111111111111111111-->
    <div class="loginl">
      <img @click="fanhu" src="../../static/img/icon_fanhui_daohang@2x.png"/>
      登录
    </div>
    <div class="icon">
      <img src="../../static/img/timg.png" alt="">
    </div>
    <div class="phone_">
      <input type="text" v-model="phone" placeholder="请输入您的邮箱号">
      <img class="shan" @click="del" src="../../static/img/icon_chacha.png"/>
    </div>
    <div class="passw" v-show="show">
      <input type="text"  v-model="password" placeholder="请输入密码">
      <img class="shan" @click="nosee" src="../../static/img/icon_bukejian@2x.png"/>
  </div>
    <div class="passwo" v-show="!show">
      <input type="password"  v-model="password" placeholder="请输入密码">
      <img class="shan" @click="see" src="../../static/img/icon_kejian@2x.png"/>
    </div>
    <div class="forget" @click="reset">
      忘记密码？
    </div>
    <div class="lo" @click="login">
      登录
    </div>
    <div class="zhuce">
      <span @click="reg">
        注册
      </span>

    </div>
  </div>
</template>

<script>
  export default {
    name: "login",
    data() {
      return {
        phone:"",
        password:"",
        show:false
      }
    },
    mounted() {
      var thats=this
      if(api.deviceId){
        api.addEventListener({
          name: 'keyback'
        }, function(ret, err) {
          thats.$router.go(-1)
        })}
    },
    methods: {
      reset(){
        this.$router.push("/reset")
      },
      reg(){
        this.$router.push("/register")
      },
      see: function () {
        this.show = true;
      },
      nosee: function () {
        this.show = false;
      },
      del: function () {
        this.phone = '';
      },
      login() {
        // if (!(/^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/.test(this.phone))) {
        //   this.meaning = true
        //   this.mean = "请输入正确的邮箱号"
        // } else if (this.password==""){
        //   this.meaning = true;
        //   this.mean = this.$t("prefix.pwdk")
        //
        //   setTimeout(()=>{
        //     this.meaning=false
        //   },2000)
        //   return false;
        // }else {
          this.$http.get(this.$store.state.url+"/v1/login", {
            params: {
              email: this.phone,
              password:this.password
            }
          }).then(res => {
            console.log(res)
            if (res.data.code==200){
              // console.log(222222222)
              this.$cookieStore.addCookie("user_id",res.data.data.user_id)
              this.$store.state.arr=[].concat([true,false,false,false,false])
              this.$router.push("/")
            }
          })
        // }
      },
      fanhu() {
        this.$router.push("/self")
      },
    }
  }
</script>

<style scoped>
  .login{
    padding-top: .49rem;
    background: white;
    min-height: 100vh;
  }
  .loginl {
    position: fixed;
    top: 0;
    left: 0;
    height: 0.49rem;
    width: 100%;
    background: #44b6e2;
    text-align: center;
    line-height: 0.49rem;
    vertical-align: middle;
    font-size: 0.18rem;
    /*font-weight: bold;*/
    color: #ffffff;
    z-index: 800;
  }
  .loginl img{
    position: absolute;
    left: .12rem;
    top: 50%;
    transform: translateY(-50%);
    width: .09rem;
    height: .15rem;
  }
  .icon img{
    width: 80%;
    height: 2.5rem;
  }
  .phone_,.passwo,.passw{
    position: relative;
  }
  .phone_ img{
    position: absolute;
    width: .25rem;
    top: .12rem;
    right: .55rem;
  }
  .passwo img,.passw img{
    position: absolute;
    width: .25rem;
    top: .3rem;
    right: .55rem;
  }
  .phone_ input{
    width: 2.79rem;
    height: 0.48rem;
    /*background: red;*/
    position: relative;
    background: #FFFFFF;
    padding-left: .2rem;
    border: .01rem solid black;
    border-radius: .06rem;
    /*margin-left: 0.48rem;*/
    /*margin-top: -0.18rem;*/
  }
  .passwo input{
    width: 2.79rem;
    height: 0.48rem;
    /*background: red;*/
    position: relative;
    background: #FFFFFF;
    padding-left: .2rem;
    border: .01rem solid black;
    border-radius: .06rem;
    /*margin-left: 0.48rem;*/
    margin-top: 0.18rem;
  }
  .passw input{
    width: 2.79rem;
    height: 0.48rem;
    /*background: red;*/
    position: relative;
    background: #FFFFFF;
    padding-left: .2rem;
    border: .01rem solid black;
    border-radius: .06rem;
    /*margin-left: 0.48rem;*/
    margin-top: 0.18rem;
  }
  .forget{
    text-align: right;
    margin-right: .3rem;
    margin-top: .05rem;
    color: #44b6e2;
  }
  .lo{
    width: 2.79rem;
    height: .4rem;
    margin: .2rem auto 0;
    line-height: .4rem;
    background: #00B2F0;
    padding:0 .1rem;
    border-radius: .1rem;
    color: white;
  }
  .zhuce{
       text-align: right;
       margin-right: .5rem;
       margin-top: .05rem;
       color: #44b6e2;
     }
</style>
