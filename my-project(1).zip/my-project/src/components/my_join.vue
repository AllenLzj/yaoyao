<template>
  <div class="my_join">
    <div class="top">
      <img src="../../static/img/icon_fanhui_daohang@2x.png" alt="" @click="back">
      <span>我加入的邀请</span>

    </div>
    <div class="bottom" v-for="li in list">
      <div class="b_top">
        <div class="b_left">
          <img :src=$store.state.url+li.path alt="">
          <div>{{li.name}}</div>
        </div>
        <div class="b_right">
          <div>
            信息：{{li.title}}
          </div>
          <div>
            地点：{{li.site}}
          </div>
          <div>
            时间：{{li.time}}
          </div>
          <div>
            附加说明：{{li.info}}
          </div>
        </div>
      </div>
      <div class="b_bottom">
        <span>【已参与{{li.num_data}}】</span>
        <!--<span>详情</span>-->
        <!--<span @click="join(li.id)">【点击参与】</span>-->
      </div>
    </div>

  </div>
</template>

<script>
  export default {
    name: "my_join",
    data(){
      return{
        sex:1,
        name:"",
        list:{}
      }
    },
    mounted(){
      this.$http.get(this.$store.state.url+"/v1/my_invitation", {params:{
          user_id:this.$cookieStore.getCookie("user_id")
        }
      }).then(res => {
        console.log(res)
        this.list=res.data.data
        console.log(this.list)
      })
      var thats=this
      if(api.deviceId){
        api.addEventListener({
          name: 'keyback'
        }, function(ret, err) {
          thats.$router.go(-1)
        })}
    },
    methods:{
      back(){
        this.$router.go(-1)
      }
    }
  }
</script>

<style scoped>
  .my_join{
    padding-top: .6rem;
  }
  .top{
    height: .5rem;
    width: 100%;
    background: #00B2F0;
    line-height: .5rem;
    color: white;
    font-size: .16rem;
    font-weight: 700;
    position: fixed;
    top: 0;
    left: 0;
  }
  .top img{
    width: .1rem;
    position: absolute;
    top: 30%;
    left: .2rem;
  }
  .bottom{
    width: 92%;
    margin: .05rem auto 0;
    border-bottom: .02rem solid #8B8378;
    padding-top: .1rem;

  }
  .b_top{
    display: flex;
    justify-content: left;
  }
  .b_left img{
    width: .5rem;
    border-radius: .25rem;
  }
  .b_right{
    margin-left: .2rem;
    text-align: left;
  }
  .b_bottom{
    display: flex;
    justify-content: space-between;
    padding: .1rem 0;
  }
  .b_bottom span:nth-child(2){
    color: blue;
  }

</style>

