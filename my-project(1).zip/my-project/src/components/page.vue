<template>
  <div class="index">
<div class="nav">
  <div class="top" @click="study">自习室</div>
  <div class="top" @click="run">体育运动</div>
  <div class="top" @click="active">社团活动</div>
  <div class="top" @click="free">课外休闲</div>
</div>
    <router-view></router-view>
  </div>
</template>

<script>
var top=document.getElementsByClassName("top")
export default {
  name: 'HelloWorld',
  data () {
    return {
    }
  },
  mounted(){
  },
  methods:{

    study(){
      this.color_change(0)
      this.$router.push({name:"study"})
    },
    run(){
      this.color_change(1)
      this.$router.push({name:"run"})
    },
    active(){
      this.color_change(2)
      this.$router.push({name:"active"})
    },
    free(){
     this.color_change(3)
      this.$router.push({name:"free"})
    },
    color_change(index){
      for (var i=0;i<top.length;i++){
        top[i].style.color="#707070"
      }
      top[index].style.color="#7FFF00"
    }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.index{
  width: 100%;
  min-height: 100vh;
  background: #E0FFFF;

}
  .nav{
    display: flex;
    justify-content: left;
    background: white;
    padding: .15rem 0;
  }
  .nav div{
    width: 25%;
    box-sizing: border-box;
    font-size: 0.15rem;
    font-weight: 800;

  }
  .top:nth-child(1){
    color: #7FFF00;
  }
</style>
