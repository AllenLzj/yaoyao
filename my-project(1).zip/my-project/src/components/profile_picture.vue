<template>
<div class="profile_picture">
  <!--头部-->
 <div class="header">
 <img @click="goBack()" src="../../static/img/icon_fanhui_daohang@2x.png" />
 <span>头像</span>
 <!-- <span @click="save">{{$t("profile_picture.save")}}</span> -->
 </div>

<div class="main">
  <!--照片-->
 <div class="boxs">
  <!-- <img src="../../../images/icon_fanhui_daohang@2x.png"> -->
  <img :src=tu />
 </div>
 <!--提示-->
 <div class="prompt">
  <p @click="bb">点击上传图片</p>
  <div id="box" v-show="btn" @click="bao">点击保存</div>
 </div>
</div>
<div class="fotter" @click="save">点击保存</div>
</div>
<!-- <p>{{$t("profile_picture.photo")}}</p> -->

</template>

<script>
  // import { DatetimePicker } from 'mint-ui';
  export default {
    name: 'profile_picture',
    data () {
      return {
        res:'',
        path:'',
        tu:'',
        btn:false,
        url:{}
      }
    },
     mounted(){


       this.$http.get(this.$store.state.url+"/v1/getPersonalData", {params: {user_id: this.$cookieStore.getCookie("user_id")}}).then(res => {
         console.log(res.data)
         this.list = res.data.data
         this.sex = res.data.data.sex
         this.name = res.data.data.name
         this.tu = this.$store.state.url + res.data.data.icon_path
       })
       var thats=this
       if(api.deviceId){
         api.addEventListener({
           name: 'keyback'
         }, function(ret, err) {
           thats.$router.go(-1)
         })}
      },
    // components:{HeaderName,FooterName},
    methods:{
      goBack() {
        this.$router.go(-1)
      },
      bb:function () {
// 点击弹出选择框
        api.actionSheet({
          cancelTitle :"取消",
          buttons : ["拍照","手机相册"]
        }, function(ret, err) {
          if (ret) {
            // 调用拍照功能
            getPicture(ret.buttonIndex);
          }
        });

        let that=this;
        let thathttp=this.$http
        //相机拍照
        function getPicture(sourceType) {
          // 1为相机拍照，2为从相册选择
          if (sourceType == 1) {
            api.getPicture({
              sourceType : 'camera',
              encodingType : 'jpg',
              mediaValue : 'pic',
              allowEdit : false,
              quality : 96,
              saveToPhotoAlbum : false
            }, function(ret, err) {
              // 获取拍照图像并剪辑
              if (!ret.data.length) {
                api.toast({
                  msg : "请使用相机拍照",
                  duration : 3000,
                  location : 'bottom'
                });
              } else {
                // 剪辑图片
                var FNImageClip = api.require('FNImageClip');
                that.btn=true;
                FNImageClip.open({
                  rect : {
                    x : 0,
                    y : 0,
                    w : api.winWidth,
                    h : api.winHeight-50
                    // - document.querySelector('#box').offsetHeight
                  },
                  srcPath : ret.data,
                  mode : 'image',
                  style : {
                    mask : 'rgba(0,0,0,0.75)',
                    clip : {
                      w : 200,
                      h : 200,
                      x : (api.frameWidth - 200) / 2,
                      y : (api.frameHeight - 200) / 2,
                      borderColor : '#0f0',
                      borderWidth : 1,
                      appearance : 'rectangle'
                    }
                  },
                }, function(ret, err) {
                   api.addEventListener({
 　　　　     name: 'keyback'
 　　             }, function(ret, err) {
 　　　　              FNImageClip.close();
                      that.btn=false;
　　                 });
                });
              }
            });
          } else if (sourceType == 2) {
            // 从相册里选择图片
            var UIMediaScanner = api.require('UIMediaScanner');
            UIMediaScanner.open({
              type : 'picture',
              column : 4,
              classify : true,
              max : 1,
              sort : {
                key : 'time',
                order : 'desc'
              },
              texts : {
                stateText : '*',
                cancelText : '✘',
                finishText : '✔'
              },
              styles : {
                bg : '#fff',
                mark : {
                  icon : '',
                  position : 'bottom_left',
                  size : 20
                },
                nav : {
                  bg : '#eee',
                  stateColor : '#000',
                  stateSize : 18,
                  cancelBg : 'rgba(0,0,0,0)',
                  cancelColor : '#000',
                  cancelSize : 18,
                  finishBg : 'rgba(0,0,0,0)',
                  finishColor : '#000',
                  finishSize : 18
                }
              },
              scrollToBottom : {
                intervalTime : -1,
                anim : true
              },
              exchange : true,
              rotation : true,

            }, function(ret) {
              if (ret) {
                that.path=ret
                if (ret.list) {
                  // alert(JSON.stringify(ret.list[0].path))
                  UIMediaScanner.transPath({
                  path:ret.list[0].path
                },function(rett,errr){
                if(rett){
                that.wei=JSON.stringify(ret.list)
                // ret.list[0].path为图片路径
              // 剪辑图片
                var FNImageClip = api.require('FNImageClip');
                that.btn=true;
                FNImageClip.open({
                  rect: {
                    x: 0,
                    y: 0,
                    w: api.winWidth,
                    h: api.winHeight - 50
                  },
                  // srcPath: rett.list[0].path,
                  srcPath: rett.path,
                  style : {
                    mask : 'rgba(0,0,0,0.75)',
                    clip : {
                      w : 200,
                      h : 200,
                      x : (api.frameWidth - 200) / 2,
                      y : (api.frameHeight - 200) / 2,
                      borderColor : '#0f0',
                      borderWidth : 0,
                      appearance : 'rectangle'
                    }
                  },
                  fixedOn: api.frameName
                }, function(ret, err) {
                  api.addEventListener({
 　　　　     name: 'keyback'
 　　             }, function(ret, err) {
 　　　　              FNImageClip.close();
                      that.btn=false;
　　                 });
          // 剪辑模块没有保存按钮，保存按钮为自己定义，，本次用了 #box
                });
              }else{
                  // alert(111111111111)
                  that.btn=false;
                  }
                })

                  }else{
                  // alert(111111111111)
                  that.btn=false;
                  }



              }
            });

          }}
      },
      bao:function () {
// 点击保存按钮
        function nub(minNum, maxNum) {
          switch(arguments.length) {
            case 1:
              return parseInt(Math.random() * minNum + 1);
              break;
            case 2:
              return parseInt(Math.random() * (maxNum - minNum + 1) + minNum);
              break;
            default:
              return 0;
              break;
          }
        }

        let thathttp=this.$http
        var that=this;
        var FNImageClip = api.require('FNImageClip');
        var nubs = nub(1000, 3000);
        FNImageClip.save({
          destPath : 'fs://tx_' + nubs + '.jpg',
          copyToAlbum : false,
          quality : 1
        }, function(ret, err) {
          // 保存按钮消失
         that.btn=false;

          // ret.destPath为返回图片路径
          // var tx = ret.destPath;
          FNImageClip.close();
          if (ret) {
            // 出现加载中
            api.showProgress({
              animationType: 'fade',
              title: "冷静下",
              text:"先喝杯茶...",
            });
           that.tu=ret.destPath
          } else {
            alert(JSON.stringify(err));
          }
           // 成功后删除加载中
              api.hideProgress();
        });
      },
      save:function(){
        let thathttp=this.$http
        var that=this;
 // 上传图片
 // if (that.tu.split(":")[0]=='http') {
 // that.$router.push('/person_before')
 // }else{
  api.ajax({
              method:"post",
              url:this.$store.state.url+"/v1/avatar_edit?user_id="+that.$cookieStore.getCookie("user_id"),
              data:{
                files: {
                  avatar:that.tu
                },

              },
              dataType:'json',
              async:true,
            },function(ret,err){
              if(ret.code==200){
                // alert(JSON.stringify(88888));
                // alert(JSON.stringify(ret));
                // that.tu=that.text1()+ ret.data.path
                // that.tu=that.text1()+ avatar
                that.$router.push('/self')
              }else {
                alert(JSON.stringify(err));
                // alert(JSON.stringify(2222222));
            }
        })
 // }
 console.log(this.tu)
            // avatar名字前后端一致

      }
    }
  }
</script>

<style scoped>
.profile_picture{
  width: 100%;
  height: 100vh;
  background: #f7f7f7;
}
/*头部*/
.header{
  width: 100%;
  height: .49rem;
  background: #44b6e2;
  position: fixed;
  top: 0;
    left: 0;
    font-size: .16rem;
    text-align: center;
    line-height: .49rem;
    font-weight: bold;
    color: #ffffff;
}
.header img{
  width: .09rem;
  height: .15rem;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: .12rem;
}
.header span:nth-child(3){
  font-size: .14rem;
  color:#00b2f0;
  position: absolute;
  right: .12rem;
}
/*照片*/
.main{
  padding: .95rem 0 0 0;
}
.boxs{
  background: #e7e7e7;
  width: 100%;
  height: 2.6rem;
  /*margin-bottom: .38rem;*/
   margin: 0 auto .38rem;
  text-align: center;
}
.boxs img{
  margin: 0 auto;

  width: 2.6rem;
  height: 2.6rem;
}
/*提示选择*/
.prompt p{
  background:#ffffff;
    border:/.01rem solid #eaeaea;
    border-radius:.06rem;
    width:2.58rem;
    height:.44rem;
    font-size: .14rem;
    text-align: center;
    line-height: .44rem;
    margin:.12rem auto;
    font-weight: bold;
}
#box{
    width: 100%;
    height: 0.52rem;
    position: fixed;
    bottom:0;
    left: 0;
    text-align: center;
    font-size: 0.16rem;
    z-index: 201;
    background: #05A3D9;
    line-height: 0.5rem;
    color: #ffffff;
  }
  .fotter{
     width: 100%;
    height: 0.52rem;
    position: fixed;
    bottom:0;
    left: 0;
    text-align: center;
    font-size: 0.16rem;
    z-index: 200;
    background: #05A3D9;
    line-height: 0.5rem;
    color: #ffffff;

  }
</style>
