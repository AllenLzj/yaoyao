<template>
  <div class="release">

    <div class="top">
      发起邀请
    </div>
    <div class="check" v-show="ch">
      <div class="ch_top">是否预约场地</div>
      <div class="ch_bot">
        <div @click="dui">预约</div>
        <div @click="cuo">否，跳过</div>
      </div>
    </div>
    <div>
      <tab class="tab" v-show="yu" v-bind:message="parentMsg" v-on:listenToChildEvent="showMsg"></tab>
    </div>
    <div class="content" v-show="choose">
      <!--<div class="first">发起邀请</div>-->
      <div class="second">
        <span>姓名</span>
        <input type="text" v-model="name" disabled>
        <span style="margin-left: .2rem">所属学院</span>
        <select id="" v-model="college">
          <option :value=index v-for="(li,index) in list">{{li}}</option>
          <!--<option value="1">计算机学院</option>-->
          <!--<option value="2">理学院</option>-->
        </select>
      </div>
      <div class="third">
        <span>身份</span>
        <select v-model="identity">
          <option value="1">学生</option>
          <option value="2">教师</option>
          <!--<option value="2">理学院</option>-->
        </select>
        <span style="margin-left: .2rem">人数要求</span>
        <input type="number" v-model="num">

      </div>
      <div class="third">
        <span>电话</span>
        <input type="text" v-model="phone">
        <span style="margin-left: .2rem">邀请类别</span>
        <select v-model="type" :disabled="check">
          <option value="1">自习</option>
          <option value="2">体育活动</option>
          <option value="3">社团活动</option>
          <option value="4">课外休闲</option>
        </select>
      </div>
      <div class="fifth">
        <div>
          标题
        </div>
        <input type="text" v-model="title">
        <div>
          地点
        </div>
        <input type="text" v-model="address" :disabled="check">
        <div>
          时间
        </div>
        <input type="text" v-model="time" :disabled="check">

        <div>
          附加说明
        </div>
        <textarea name="" cols="30" rows="5" v-model="other"></textarea>

        <div class="sub">
          <div @click="release">发布邀请</div>
          <div @click="reset">重置内容</div>
        </div>
      </div>
    </div>
    <div style="min-height: 0.28rem;" class="qing">
      <div class="css" v-show="meaning">{{mean}}</div>
    </div>
  </div>
</template>

<script>
  import tab from '@/components/tab'

  export default {
    name: "release",
    components: {tab},
    data() {
      return {
        list: [],
        college: 1,
        name: "",
        identity: 1,
        num: "",
        phone: "",
        type: 1,
        address: '',
        time: '',
        other: "",
        title: "",
        meaning: false,
        mean: "",
        choose: false,
        yu: false,
        ch: true,
        parentMsg: "",
        check: false,
        time_ids:"",

      }
    },
    mounted() {
      if (this.$cookieStore.getCookie("user_id")) {
      this.$http.get(this.$store.state.url + "/v1/get_academy", {}).then(res => {
        console.log(res)
        this.list = res.data.data
        console.log(this.list)
      })


        this.$http.get(this.$store.state.url + "/v1/getPersonalData", {params: {user_id: this.$cookieStore.getCookie("user_id")}}).then(res => {
          console.log(res.data)
          this.name = res.data.data.name

        })
      } else {
        this.meaning = true
        this.mean = "请先登录"
        setTimeout(() => {
          this.meaning = false
        }, 1500)
      }
      var first = null;
      if (api.deviceId) {
        api.addEventListener({
          name: 'keyback'
        }, (res, err) => {
          if (!first) {
            first = new Date().getTime();//记录第一次按下回退键的时间
            api.toast({
              msg: '再点一次退出应用',
              duration: 2000,
              location: 'bottom'
            });
            // history.go(-1)//回退到上一页面
            setTimeout(function () {//1s中后清除
              first = null;
            }, 1000);
          } else {
            if (new Date().getTime() - first < 2000) {//如果两次按下的时间小于1s，
              api.closeWidget({
                silent: true
              });
            }
          }
        });
      }
    },
    methods: {
      showMsg(data) {

        console.log(data)
        this.type = data.type
        this.address = data.name
        this.time = data.time_text
        this.time_ids=data.time_ids
        this.choose = true
        this.ch = false
        this.yu = false
        this.check = true
      },
      dui() {
        this.yu = true
        this.ch = false
      },
      cuo() {
        this.choose = true
        this.ch = false
      },
      release() {
        if (this.$cookieStore.getCookie("user_id")) {


          if (this.name != "" && this.num != "" && this.phone != "" && this.address != "" && this.time != "" && this.other != "" && this.title != "") {
            let qs = require('qs')
            this.$http.post(this.$store.state.url + "/v1/add_invitation", qs.stringify({
                user_id: this.$cookieStore.getCookie("user_id"),
                type: this.type,
                title: this.title,
                info: this.other,
                site: this.address,
                time: this.time,
                user_num: this.num,
                name: this.name,
                identity: this.identity,
                academy_id: this.college,
                time_ids:this.time_ids

              })
            ).then(res => {
              console.log(res)
              this.$store.state.arr = [].concat([true, false, false, false, false])
              this.$router.push("/")
            })
          } else {
            this.meaning = true
            this.mean = "请将信息填写完整"
            setTimeout(() => {
              this.meaning = false
            }, 1500)
          }
        } else {
          this.meaning = true
          this.mean = "请先登录"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }
      },
      reset() {
        this.college = 1
        this.name = ""
        this.identity = 1
        this.num = ""
        this.phone = ""
        if (this.check==false) {
          this.type = 1
          this.address = ""
          this.time = ""
        }
        this.other = ""
      }
    }
  }
</script>

<style scoped>
  input, textarea {
    border: 1px solid #5a5a5a;
    padding: .02rem;
    /*box-sizing: border-box;*/
  }

  select {
    border: 1px solid #5a5a5a;
    padding: .02rem 0;
    /*box-sizing: border-box;*/
  }

  .top {
    height: .5rem;
    width: 100%;
    background: #00B2F0;
    line-height: .5rem;
    color: white;
    font-size: .16rem;
    font-weight: 700;
    position: fixed;
    top: 0;
    left: 0;
  }

  .release {
    padding-top: .8rem;
    box-sizing: border-box;
    min-height: 100vh;
  }

  .content {
    width: 96%;
    margin: 0 auto;
    /*border-top: .02rem solid black;*/
    text-align: left;
  }

  .first {
    margin-top: .2rem;
    font-size: .16rem;
    text-align: center;
    margin-bottom: .3rem;
  }

  .second, .third {
    margin-top: .1rem;
    margin-left: .2rem;
  }

  .second input, .third input {
    width: 30%;
  }

  select {
    width: 31%;
  }

  .fifth {
    margin: 0 .2rem;
  }

  .fifth input, textarea {
    width: 100%;
    margin-top: .1rem;
  }

  .fifth > div {
    margin-top: .1rem;
  }

  .fifth .sub {
    display: flex;
    justify-content: space-around;
    margin-top: .3rem;
  }

  .sub div {
    border: 1px solid black;
    padding: .05rem;
    border-radius: .05rem;
  }

  .css {
    margin: .08rem auto 0;
    border: .01rem solid #EAEAEA;
    border-radius: .06rem;
    text-align: center;
    width: 70%;
    min-height: 0.18rem;
    font-family: PingFangSC-Regular;
    font-size: 0.14rem;
    /*color: #666;*/
    background: white;
    color: red;
    letter-spacing: 0;
    padding: .1rem;
    position: fixed;
    top: 3.8rem;
    left: 12%;
    z-index: 111;
    /*margin-top: -0.27rem;*/
  }

  .check {
    width: 70%;
    margin-left: 15%;
    border: 1px solid lightgrey;
    position: fixed;
    top: 30%;
  }

  .ch_top {
    margin-top: .2rem;
  }

  .ch_bot {
    display: flex;
    justify-content: space-around;
    margin: .2rem 0;
  }

  .ch_bot div {
    width: .8rem;
    border: 1px solid lightgrey;
  }

  .tab {
    width: 90%;
    margin-left: 5%;
  }
</style>
