<template>
  <div class="reset">
    <!--1111111111111111111111111-->
    <div class="loginl">
      <img @click="fanhu" src="../../static/img/icon_fanhui_daohang@2x.png"/>
      重置密码
    </div>
    <!--<div class="icon">-->
      <!--<img src="../../static/img/timg.jpg" alt="">-->
    <!--</div>-->
    <div class="phone_">
      <input type="text" v-model="phone" placeholder="请输入您的邮箱号">
      <img class="shan" @click="del" src="../../static/img/icon_chacha.png"/>
    </div>
    <div class="code">
      <input type="number" v-model="code" placeholder="请输入验证码">
      <div @click="h_code" v-show="co">{{huo}}</div>
      <div style="font-size: .18rem" v-show="!co">{{num}}</div>
    </div>
    <div class="passw" v-show="show">
      <input type="text"  v-model="password" placeholder="请输入密码">
      <img class="shan" @click="nosee" src="../../static/img/icon_bukejian@2x.png"/>
    </div>
    <div class="passwo" v-show="!show">
      <input type="password"  v-model="password" placeholder="请输入密码">
      <img class="shan" @click="see" src="../../static/img/icon_kejian@2x.png"/>
    </div>
    <div class="passw" v-show="show1">
      <input type="text"  v-model="password1" placeholder="请输入密码">
      <img class="shan" @click="nosee1" src="../../static/img/icon_bukejian@2x.png"/>
    </div>
    <div class="passwo" v-show="!show1">
      <input type="password"  v-model="password1" placeholder="请输入密码">
      <img class="shan" @click="see1" src="../../static/img/icon_kejian@2x.png"/>
    </div>
    <!--<div class="forget">-->
      <!--忘记密码？-->
    <!--</div>-->
    <div class="lo" @click="reset">
      提交
    </div>
    <div style="min-height: 0.28rem;" class="qing">
      <div class="css" v-show="meaning">{{mean}}</div>
    </div>
    <!--<div class="zhuce" @click="reg">-->
      <!--注册-->
    <!--</div>-->
  </div>
</template>

<script>
  export default {
    name: "reset",
    data() {
      return {
        phone:"",
        password:"",
        show:false,
        code:"",
        password1:'',
        show1:false,
        meaning: false,
        num:59,
        co:true,
        mean: "",
        huo:"获取验证码"
      }
    },
    mounted() {
      var thats=this
      if(api.deviceId){
        api.addEventListener({
          name: 'keyback'
        }, function(ret, err) {
          thats.$router.go(-1)
        })}
    },
    methods: {
      reset(){
        if (!(/^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/.test(this.phone))) {
          this.meaning = true
          this.mean = "请输入正确的邮箱号"
        } else {
          this.$http.get(this.$store.state.url+"/v1/email_password", {
            params: {
              email: this.phone,
              code: this.code,
              password: this.password
            }
          }).then(res => {
            console.log(res)
            if (res.data.code == 200) {
              this.$router.push("/login")
            } else {
              this.meaning = true
              this.mean = res.data.message
            }
          })
        }
      },
      reg(){
        this.$router.push("/register")
      },
      see: function () {
        this.show = true;
      },
      nosee: function () {
        this.show = false;
      },
      see1: function () {
        this.show1 = true;
      },
      nosee1: function () {
        this.show1 = false;
      },
      del: function () {
        this.phone = '';
      },
      login() {

      },
      fanhu() {
        this.$router.go(-1)
      },
      h_code(){

        if (!(/^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/.test(this.phone))) {
          this.meaning = true
          this.mean = "请输入正确的邮箱号"
        } else {
          this.$http.get(this.$store.state.url+"/v1/sendEmail", {
            params: {
              email: this.phone
              // code:""
            }
          }).then(res => {
            console.log(res)
            this.co=false
            var timer=setInterval(()=>{
              this.num--
              if (this.num==0){
                this.co=true
                clearInterval(timer)
                this.num=10
                this.huo="重新获取"
              }
            },1000)
          })
        }
      }
    }
  }
</script>

<style scoped>
  .reset{
    padding-top: 1.09rem;
  }
  .loginl {
    position: fixed;
    top: 0;
    left: 0;
    height: 0.49rem;
    width: 100%;
    background: #44b6e2;
    text-align: center;
    line-height: 0.49rem;
    vertical-align: middle;
    font-size: 0.18rem;
    /*font-weight: bold;*/
    color: #ffffff;
    z-index: 800;
  }
  .loginl img{
    position: absolute;
    left: .12rem;
    top: 50%;
    transform: translateY(-50%);
    width: .09rem;
    height: .15rem;
  }
  .icon img{
    width: 80%;
    height: 2.5rem;
  }
  .phone_,.passwo,.passw,.code{
    position: relative;
  }
  .code input{
    width: 2.79rem;
    height: 0.48rem;
    /*background: red;*/
    position: relative;
    background: #FFFFFF;
    padding-left: .2rem;
    border: .01rem solid black;
    border-radius: .06rem;
    /*margin-left: 0.48rem;*/
    margin-top: 0.18rem;
  }
  .code div{
    position: absolute;
    width: 1rem;
    /*background: red;*/
    padding: .05rem .1rem;
    right: .4rem;
    top: .28rem;
    border-left: 1px solid lightgrey;
    color: #007aff;
  }
  .phone_ img{
    position: absolute;
    width: .25rem;
    top: .1rem;
    right: .45rem;
  }
  .passwo img,.passw img{
    position: absolute;
    width: .25rem;
    top: .3rem;
    right: .45rem;
  }
  .phone_ input{
    width: 2.79rem;
    height: 0.48rem;
    /*background: red;*/
    position: relative;
    background: #FFFFFF;
    padding-left: .2rem;
    border: .01rem solid black;
    border-radius: .06rem;
    /*margin-left: 0.48rem;*/
    /*margin-top: -0.18rem;*/
  }
  .passwo input{
    width: 2.79rem;
    height: 0.48rem;
    /*background: red;*/
    position: relative;
    background: #FFFFFF;
    padding-left: .2rem;
    border: .01rem solid black;
    border-radius: .06rem;
    /*margin-left: 0.48rem;*/
    margin-top: 0.18rem;
  }
  .passw input{
    width: 2.79rem;
    height: 0.48rem;
    /*background: red;*/
    position: relative;
    background: #FFFFFF;
    padding-left: .2rem;
    border: .01rem solid black;
    border-radius: .06rem;
    /*margin-left: 0.48rem;*/
    margin-top: 0.18rem;
  }
  .forget{
    text-align: right;
    margin-right: .3rem;
    margin-top: .05rem;
    color: #44b6e2;
  }
  .lo{
    width: 2.79rem;
    height: .5rem;
    margin: .4rem auto 0;
    line-height: .5rem;
    background: #00B2F0;
    padding:0 .1rem;
    border-radius: .1rem;
    color: white;
  }
  .zhuce{
    text-align: right;
    margin-right: .5rem;
    margin-top: .05rem;
    color: #44b6e2;
  }
  .css {
    margin: .08rem auto 0;
    border: .01rem solid #EAEAEA;
    border-radius: .06rem;
    text-align: center;
    width: 2.59rem;
    min-height: 0.18rem;
    font-family: PingFangSC-Regular;
    font-size: 0.14rem;
    /*color: #666;*/
    color: red;
    letter-spacing: 0;
    padding: .1rem;
    /*margin-top: -0.27rem;*/
  }
</style>
