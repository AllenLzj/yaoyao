<template>
  <div class="self">
    <div class="top">
      <div class="my">我的</div>
      <img src="../../static/img/top.png" alt="">
      <div class="center" v-show="!show">
        <div class="pic">
          <img :src=url alt="">
        </div>
        <div>
          <span>{{list.name}}</span>
          <i v-show="list.sex==1"><img src="../../static/img/icon_nan@2x.png" alt="" style="width: .11rem"></i>
          <i v-show="list.sex==2"><img src="../../static/img/icon_nv@2x.png" alt="" style="width: .11rem"></i>
          <i v-show="list.is_authentication">
            <img src="../../static/img/r.png" alt="" style="width: .13rem">
          </i>
        </div>
        <!--<div>-->
        <!--经济管理学院-->
        <!--</div>-->
      </div>
      <div class="center" v-show="show">
        <div class="pic">
          <img src="../../static/img/1.png" alt="">
        </div>
        <div class="login" @click="login">
          请点击登陆账号
        </div>
      </div>
    </div>
    <div class="hang" @click="yan">
      <img src="../../static/img/set2.png" alt="">
      <span>身份认证</span>
      <img src="../../static/img/icon_sousuojiaolian@2x.png" alt="">
    </div>
    <div class="hang" @click="edit">
      <img src="../../static/img/set2.png" alt="">
      <span>修改资料</span>
      <img src="../../static/img/icon_sousuojiaolian@2x.png" alt="">
    </div>
    <div class="hang" @click="my_release">
      <img src="../../static/img/set2.png" alt="">
      <span>我发布的邀请</span>
      <img src="../../static/img/icon_sousuojiaolian@2x.png" alt="">
    </div>
    <div class="hang" @click="my_join">
      <img src="../../static/img/set2.png" alt="">
      <span>我参与的邀请</span>
      <img src="../../static/img/icon_sousuojiaolian@2x.png" alt="">
    </div>

    <!--<div class="hang" @click="write">-->
      <!--<img src="../../static/img/set2.png" alt="">-->
      <!--<span>分享文章</span>-->
      <!--<img src="../../static/img/icon_sousuojiaolian@2x.png" alt="">-->
    <!--</div>-->
    <div class="hang" @click="tuichu">
      <img src="../../static/img/set2.png" alt="">
      <span>退出登录</span>
      <img src="../../static/img/icon_sousuojiaolian@2x.png" alt="">
    </div>
    <div style="min-height: 0.28rem;" class="qing">
      <div class="css" v-show="meaning">{{mean}}</div>
    </div>

  </div>
</template>

<script>
  export default {
    name: "self",
    data() {
      return {
        show: false,
        list: {},
        url: "",
        meaning: false,
        mean: "",

      }
    },
    mounted() {
      console.log(this.$store.state.url)
      if (this.$cookieStore.getCookie("user_id")) {
        console.log(111111111)
        this.$http.get(this.$store.state.url + "/v1/getPersonalData", {params: {user_id: this.$cookieStore.getCookie("user_id")}}).then(res => {
          console.log(res.data)
          this.list = res.data.data
          this.url = this.$store.state.url + this.list.icon_path
          this.show = false
        })
      } else {
        this.show = true
      }
      var first = null;
      if (api.deviceId) {
        api.addEventListener({
          name: 'keyback'
        }, (res, err) => {
          if (!first) {
            first = new Date().getTime();//记录第一次按下回退键的时间
            api.toast({
              msg: '再点一次退出应用',
              duration: 2000,
              location: 'bottom'
            });
            // history.go(-1)//回退到上一页面
            setTimeout(function () {//1s中后清除
              first = null;
            }, 1000);
          } else {
            if (new Date().getTime() - first < 2000) {//如果两次按下的时间小于1s，
              api.closeWidget({
                silent: true
              });
            }
          }
        });
      }
    },
    methods: {
      login() {
        this.$router.push({name: "login"})
      },

      tuichu() {
        if (this.$cookieStore.getCookie("user_id")) {
          this.$http.get(this.$store.state.url + "/v1/logout", {
            params: {user_id: this.$cookieStore.getCookie("user_id")}
          }).then(res => {
            console.log(res)
            this.$cookieStore.delCookie("user_id")
            this.$store.state.arr = [].concat([true, false, false, false, false])
            console.log(this.$store.state.arr)
            this.$router.push("/")
            // location.reload()
            // if (res.data.code==200){
            //   // console.log(222222222)
            //   this.$cookieStore.addCookie("user_id",res.data.data.user_id)
            //   this.$router.push("/")
            // }
          })
        } else {
          this.meaning = true
          this.mean = "请先登录"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }

      },
      edit() {
        if (this.$cookieStore.getCookie("user_id")) {
          this.$router.push("/edit")
        } else {
          this.meaning = true
          this.mean = "请先登录"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }
      },
      my_release() {
        if (this.$cookieStore.getCookie("user_id")) {
          this.$router.push("/my_release")
        } else {
          this.meaning = true
          this.mean = "请先登录"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }
      },
      my_join() {
        if (this.$cookieStore.getCookie("user_id")) {
          this.$router.push("/my_join")
        } else {
          this.meaning = true
          this.mean = "请先登录"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }
      },
      write() {
        if (this.$cookieStore.getCookie("user_id")) {
          this.$router.push("/write")
        } else {
          this.meaning = true
          this.mean = "请先登录"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }
      },
      yan() {
        if (this.$cookieStore.getCookie("user_id")) {
          this.$router.push("/yan")
        } else {
          this.meaning = true
          this.mean = "请先登录"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }
      }
    }
  }
</script>

<style scoped>
  .self {
    width: 100%;
    min-height: 100vh;
    background: rgb(234, 234, 234);
  }

  .top img {
    width: 100%;

  }

  .top {
    position: relative;
    height: 2.4rem;
    background: white;
    margin-bottom: .08rem;
  }

  .my {
    position: absolute;
    top: .15rem;
    text-align: center;
    width: 100vw;
    font-size: .16rem;
    color: white;
    font-weight: 700;
  }

  .center {
    background: url("../../static/img/edit.png") no-repeat;
    background-size: 100% 100%;
    width: 60%;
    height: 1.3rem;
    position: absolute;
    left: 20%;
    top: .7rem;
  }

  .pic img {
    width: .8rem;
    border-radius: .4rem;
  }

  .pic {
    margin-top: .1rem;

  }

  .hang {
    /*margin-top: .08rem;*/
    background: white;
    text-align: left;
    position: relative;
    padding: .1rem .15rem;
    border-top: 1px solid lightgrey;
  }

  .hang img:nth-child(1) {
    width: .2rem;
    vertical-align: middle;
    margin-right: .05rem;
  }

  .hang img:nth-child(3) {
    width: .12rem;
    position: absolute;
    top: .1rem;
    right: .15rem;
  }

  .login {
    color: rgb(255, 130, 71);
    margin-top: .05rem;
  }

  .css {
    margin: .08rem auto 0;
    border: .01rem solid #EAEAEA;
    border-radius: .06rem;
    text-align: center;
    width: 70%;
    min-height: 0.18rem;
    font-family: PingFangSC-Regular;
    font-size: 0.14rem;
    /*color: #666;*/
    background: white;
    color: red;
    letter-spacing: 0;
    padding: .1rem;
    position: fixed;
    top: 5rem;
    left: 12%;
    z-index: 111;
    /*margin-top: -0.27rem;*/
  }
</style>
