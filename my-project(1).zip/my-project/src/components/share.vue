<template>
  <div class="share">
    <div class="nav">
      <div class="top1" @click="study">自习室</div>
      <div class="top1" @click="run">体育运动</div>
      <div class="top1" @click="active">社团活动</div>
      <div class="top1" @click="free">课外休闲</div>
    </div>
    <div class="container">
      <input type="text" class="sear" placeholder="请输入你要搜索的关键词">
      <div class="search"></div>
    </div>
    <div class="center">
      <img src="../../static/img/wait.png" alt="">
      <span>等你加入</span>
      <span class="fa" @click="write">发帖</span>
    </div>
    <div class="bottom" v-for="li in list.announcement">
      <div class="b_top">
        <div class="b_left">
          <img src="../../static/img/1.png" alt="">
          <div>{{li.name}}</div>
        </div>
        <div class="b_right">
          <div>
            公告：{{li.title}}
          </div>
          <div>
            时间：{{li.create_time}}
          </div>
          <div class="info">
            内容：{{li.info}}
          </div>
          <!--<div>-->
          <!--附加说明：{{li.info}}-->
          <!--</div>-->
        </div>
      </div>
      <div class="b_bottom">
        <!--<span>【已参与{{li.num_data}}】</span>-->
        <!--<span>详情</span>-->
        <span @click="join(li.id,1)">【点击查看详细内容】</span>
      </div>
    </div>

    <div class="bottom" v-for="li in list.article">
      <div class="b_top">
        <div class="b_left">
          <img :src=$store.state.url+li.path alt="" @click="detail(li)">
          <div>{{li.name}}</div>
        </div>
        <div class="b_right">
          <div>
            分享帖：{{li.title}}
          </div>
          <div>
            时间：{{li.create_time}}
          </div>
          <div class="info">
            内容：{{li.info}}
          </div>
          <!--<div>-->
          <!--附加说明：{{li.info}}-->
          <!--</div>-->
        </div>
      </div>
      <div class="b_bottom">
        <!--<span>【已参与{{li.num_data}}】</span>-->
        <!--<span>详情</span>-->
        <span @click="join(li.id,2)">【点击查看详细内容】</span>
      </div>
    </div>
    <!--<div class="bottom" v-for="li in list.article">-->
      <!--<div class="b_top">-->
        <!--<div class="b_left">-->
          <!--<img src="../../static/img/1.png" alt="">-->
          <!--<div>{{li.name}}</div>-->
        <!--</div>-->
        <!--<div class="b_right">-->
          <!--<div>-->
            <!--分享帖：{{li.title}}-->
          <!--</div>-->
          <!--<div>-->
            <!--时间：{{li.create_time}}-->
          <!--</div>-->
          <!--<div class="info">-->
            <!--内容：{{li.info}}-->
          <!--</div>-->
          <!--&lt;!&ndash;<div>&ndash;&gt;-->
          <!--&lt;!&ndash;附加说明：{{li.info}}&ndash;&gt;-->
          <!--&lt;!&ndash;</div>&ndash;&gt;-->
        <!--</div>-->
      <!--</div>-->
      <!--<div class="b_bottom">-->
        <!--&lt;!&ndash;<span>【已参与{{li.num_data}}】</span>&ndash;&gt;-->
        <!--&lt;!&ndash;<span>详情</span>&ndash;&gt;-->
        <!--<span @click="join(li.id)">【点击查看详细内容】</span>-->
      <!--</div>-->
    <!--</div>-->
    <div style="min-height: 0.28rem;" class="qing">
      <div class="css" v-show="meaning">{{mean}}</div>
    </div>
    <div class="mask" v-show="show" @click="can">
      <div class="chu">
        <div class="topp"><img src="../../static/img/jia.png" alt="" v-show="show1" @click="tianjia"></div>
        <div class="imgg"><img :src=$store.state.url+text.path alt=""></div>
        <div class="con"><span>{{text.name}}</span></div>

      </div>
    </div>
  </div>
</template>

<script>
  import {Swiper, swiperSlide} from 'vue-awesome-swiper'

  var top = document.getElementsByClassName("top1")
  export default {
    name: "share",
    data() {
      return {

        list: [],
        meaning: false,
        mean: "",
        type:1,
        text: {},
        show: false,
        show1:false
      }
    },

    mounted() {

      this.fun(1)
      var first = null;
      if (api.deviceId) {
        api.addEventListener({
          name: 'keyback'
        }, (res, err) => {
          if (!first) {
            first = new Date().getTime();//记录第一次按下回退键的时间
            api.toast({
              msg: '再点一次退出应用',
              duration: 2000,
              location: 'bottom'
            });
            // history.go(-1)//回退到上一页面
            setTimeout(function () {//1s中后清除
              first = null;
            }, 1000);
          } else {
            if (new Date().getTime() - first < 2000) {//如果两次按下的时间小于1s，
              api.closeWidget({
                silent: true
              });
            }
          }
        });
      }
    },
    methods: {
      tianjia(){
        this.$http.get(this.$store.state.url + "/v1/friend_add", {
          params: {
            user_id: this.$cookieStore.getCookie("user_id"),
            friend_user_id: this.text.user_id
          }
        }).then(res => {
          console.log(res)
          if (res.data.code==200){
            this.show=false
            this.show1=false
            this.meaning=true
            this.mean="添加好友成功"
            setTimeout(()=>{
              this.meaning=false
            },1500)
          }

        })
      },
      can(e){
        console.log(e.target.className)
        if (e.target.className=="mask"){
          this.show=false
          this.show1=false
        }
      },
      detail(li) {
        this.text = li
        this.$http.get(this.$store.state.url + "/v1/friend_is", {
          params: {
            user_id: this.$cookieStore.getCookie("user_id"),
            friend_user_id: li.user_id
          }
        }).then(res => {
          console.log(res)

          this.show = true
          if (res.data.data.is_friend==0){
            this.show1 = true
          }
        })
      },
      fun(i) {
        if (this.$cookieStore.getCookie("user_id")) {
          this.$http.get(this.$store.state.url + "/v1/article_index", {
            params: {
              type: i,
              user_id: this.$cookieStore.getCookie("user_id"),
              // search:"文章"
            }
          }).then(res => {
            console.log(res)
            this.list = res.data.data
            console.log(this.list)
          })
        } else {
          this.meaning = true
          this.mean = "请先登录"
          // setTimeout(()=>{
          //   this.meaning=false
          // },1500)
        }
      },
      write() {
        if (this.$cookieStore.getCookie("user_id")) {
          this.$router.push("/write")
        } else {
          this.meaning = true
          this.mean = "请先登录"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }
      },
      join(id,type) {
        this.$router.push({name: "article", query: {li: id,type:type,ty:this.type}})
      },
      study() {
        this.color_change(0)
        this.fun(1)
        this.type=1
        // this.$router.push({name:"study"})
      },
      run() {
        this.color_change(1)
        this.fun(2)
        this.type=2
        // this.$router.push({name:"run"})
      },
      active() {
        this.fun(3)
        this.type=3
        this.color_change(2)
        // this.$router.push({name:"active"})
      },
      free() {
        this.fun(4)
        this.type=4
        this.color_change(3)
        // this.$router.push({name:"free"})
      },
      color_change(index) {
        for (var i = 0; i < top.length; i++) {
          top[i].style.color = "#707070"
        }
        top[index].style.color = "#7FFF00"
      }
    }
  }

</script>

<style scoped>
  .share {
    /*padding: .6rem 0 0 0;*/
    min-height: 6rem;
  }

  .top {
    height: .5rem;
    width: 100%;
    background: #00B2F0;
    line-height: .5rem;
    color: white;
    font-size: .16rem;
    font-weight: 700;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 100;
  }

  .container {
    position: relative;
    /*margin-top: .6rem;*/
    margin-top: .1rem;
  }

  .sear {
    width: 92%;
    border-radius: .05rem;
    padding: .05rem;
    border: 1px solid lightgrey;
  }

  .search {
    background-image: url("../../static/img/sear.png");
    background-size: 100% 100%;
    position: absolute;
    width: .2rem;
    height: .2rem;
    top: .04rem;
    right: 5%;
    z-index: 99;
  }

  .center {
    font-size: .16rem;
    text-align: left;
    margin-left: 5%;
    margin-top: .1rem;
  }

  .center img {
    width: .25rem;
    vertical-align: middle;
  }

  .bottom {
    width: 92%;
    margin: .05rem auto 0;
    border-top: .02rem solid #8B8378;
    padding-top: .1rem;

  }

  .b_top {
    display: flex;
    justify-content: left;
  }

  .b_left img {
    width: .5rem;
    border-radius: .25rem;
  }

  .b_right {
    margin-left: .2rem;
    text-align: left;
  }

  .b_bottom {
    text-align: right;
    padding: .1rem 0;
  }

  .b_bottom span {
    color: blue;
  }

  .c_top {
    text-align: left;
  }

  .css {
    margin: .08rem auto 0;
    border: .01rem solid #EAEAEA;
    border-radius: .06rem;
    text-align: center;
    width: 70%;
    min-height: 0.18rem;
    font-family: PingFangSC-Regular;
    font-size: 0.14rem;
    /*color: #666;*/
    background: white;
    color: red;
    letter-spacing: 0;
    padding: .1rem;
    position: fixed;
    top: 5rem;
    left: 12%;
    z-index: 111;
    /*margin-top: -0.27rem;*/
  }

  .nav {
    display: flex;
    justify-content: left;
    background: white;
    padding: .15rem 0;
  }

  .nav div {
    width: 25%;
    box-sizing: border-box;
    font-size: 0.15rem;
    font-weight: 800;

  }

  .top1:nth-child(1) {
    color: #7FFF00;
  }

  .fa {
    margin-left: 1.9rem;
    font-size: .14rem;
    display: inline-block;
    border: 1px solid black;
    padding: 0 .1rem;
    border-radius: .05rem;

  }
  .mask {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0);
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1111;
  }

  .chu {
    width: 60%;
    margin-left: 20%;
    background: white;
    margin-top: 2rem;
    border-radius: .1rem;
    padding-top: .1rem;
    padding-bottom: .1rem;
  }

  .imgg img {
    width: .6rem;
    border-radius: .02rem;
  }

  .con {
    margin: .1rem;
  }
  .topp img{
    width: .2rem;
    /*vertical-align: middle;*/
    /*margin-left: .1rem;*/

  }
  .topp{
    text-align: right;
    margin-right: .2rem;
  }
</style>
