<template>
  <div class="tab">
    <div v-show="show1">
      <div style="text-align: right;padding: .1rem .1rem 0 0">
        <input type="date" v-model="date" @change="cli">
      </div>
      <div class="title">
        <div class="top1" @click="study">自习室</div>
        <div class="top1" @click="run">运动场馆</div>
        <div class="top1" @click="active">会议室</div>
      </div>
      <table>
        <tr>
          <th></th>
          <th>可使用时间段</th>
          <th>已占用时间段</th>
          <!--<th>是否空闲</th>-->
        </tr>
        <tr v-for="li in list">
          <td style="color: #007aff" @click="yuyue(li.id)">{{li.name}}</td>
          <td>{{li.kx}}</td>
          <td>{{li.zy}}</td>
          <!--<td>是</td>-->
        </tr>
      </table>
    </div>
    <div style="padding-top: .4rem" v-show="show2">
      <div class="first">预约申请</div>
      <div class="second">
        <span>预约人</span>
        <input type="text" v-model="name">
      </div>
      <div class="second">
        <span>资源类别</span>
        <input type="text" v-model="type">
      </div>
      <div class="second">
        <span>资源名称</span>
        <input type="text" v-model="add">
      </div>
      <div class="second1">
        <span>使用时间</span>
        <span style="display: inline-block;width: .4rem" v-for="ar in arr">
        <label>{{ar}}</label>
        <input type="checkbox" :value=ar v-model="time">
</span>
      </div>
      <button @click="sub">预约</button>
    </div>
    <div style="padding-top: .4rem" v-show="show3">
      <div class="first">预约结果</div>
      <div class="second">
        <span>预约人</span>
        <input type="text" v-model="name" disabled>
      </div>
      <div class="second">
        <span>资源类别</span>
        <input type="text" v-model="type" disabled>
      </div>
      <div class="second">
        <span>资源名称</span>
        <input type="text" v-model="add" disabled>
      </div>
      <div class="second">
        <span>使用时间</span>
        <input type="text" v-model="da.time_text" disabled>

      </div>
      <button @click="tiao">发起邀请</button>
    </div>
    <div style="min-height: 0.28rem;" class="qing">
      <div class="css" v-show="meaning">{{mean}}</div>
    </div>
  </div>
</template>

<script>
  var top = document.getElementsByClassName("top1")
  export default {
    name: "tab",
    props:["message"],
    data() {
      return {
        list: [],
        date: "",
        show1: true,
        show2: false,
        show3: false,
        name: "",
        type: 1,
        time: [],
        add: "",
        arr: [],
        id:"",
        da:{},
        meaning: false,
        mean: "",
      }
    },
    mounted() {
      this.cli()
      var day=new Date()
      if (day.getMonth()+1<10){
        var mou="0"+(day.getMonth()+1)
      } else{
        var mou=day.getMonth()+1
      }
      if (day.getDate()<10){
        var da="0"+(day.getDate())
      } else{
        var da=day.getDate()
      }
      this.date=day.getFullYear()+"-"+mou+"-"+da
      console.log(day.getFullYear()+"-"+mou+"-"+da)
    },
    methods: {
      cli() {
        console.log(this.date)
        this.$http.get(this.$store.state.url + "/v1/place_index", {
          params: {
            type: this.type,
            date: this.date,
            user_id: this.$cookieStore.getCookie("user_id")
          }
        }).then(res => {
          console.log(res)
          this.list = res.data.data
          console.log(this.list)
        })
      },
      yuyue(id) {
        console.log(id)

          this.id=id
          this.show1 = false
          this.show2 = true
          this.$http.get(this.$store.state.url + "/v1/place_details", {
            params: {
              id: id,
              date: this.date,
              user_id: this.$cookieStore.getCookie("user_id")
            }
          }).then(res => {
            console.log(res)
            this.add = res.data.data.name
            this.type = res.data.data.type_text
            this.arr = res.data.data.time
            this.name = res.data.data.user_name
          })



      },
      sub(){
        console.log(this.time.length)
        if (this.time.length!=0){
        this.$http.get(this.$store.state.url + "/v1//place_save", {
          params: {
            id: this.id,
            date: this.date,
            user_id: this.$cookieStore.getCookie("user_id"),
            time:this.time.join(",")
          }
        }).then(res => {
          console.log(res)
         this.da=res.data.data
          this.show2=false
          this.show3=true
        })
        }else{
          this.meaning = true
          this.mean = "请选择时间"
          setTimeout(() => {
            this.meaning = false
          }, 1500)
        }
      },
      tiao(){
        console.log(this.da)
        this.$emit("listenToChildEvent",this.da)
      },

      study() {
        this.type=1
        this.color_change(0)
        this.cli()
        // this.$router.push({name:"study"})
      },
      run() {
        this.type=2
        this.color_change(1)
        this.cli()
        // this.$router.push({name:"run"})
      },
      active() {
        this.type=3
        this.cli()
        this.color_change(2)
        // this.$router.push({name:"active"})
      },
      color_change(index) {
        for (var i = 0; i < top.length; i++) {
          top[i].style.color = "#707070"
        }
        top[index].style.color = "#7FFF00"
      }
    }
  }
</script>

<style scoped>

  .title {
    display: flex;
    justify-content: space-around;
    background: white;
    padding: .15rem 0;
    border-bottom: 1px solid lightgrey;
  }

  .title div {
    /*width: 33%;*/
    box-sizing: border-box;
    font-size: 0.15rem;
    font-weight: 800;

  }

  .top1:nth-child(1) {
    color: #7FFF00;
  }

  table {
    width: 90%;
    margin-left: 5%;
    margin-top: .2rem;
  }

  table tr {
    height: .4rem;
  }

  td, th {
    width: 25%;
    padding-right: .2rem;
  }

  .tab {
    background: white;
    min-height: 4.5rem;
  }

  .first {
    font-size: .18rem;
    margin-bottom: .6rem;
  }

  .second {
    margin-top: .2rem;
    text-align: left;
    margin-left: .4rem;
  }

  .second span {
    display: inline-block;
  }

  .second span {

    width: .7rem;
  }

  .second input {

    width: 1.8rem;
  }

  .second1 {
    margin-top: .2rem;
    text-align: left;
    margin-left: .4rem;
  }

  .second1 span {
    display: inline-block;
    width: .7rem;
  }

  .second1 span span {
    display: inline-block;
    width: .4rem;
  }

  button {
    margin-top: .3rem;
    padding: .05rem .15rem;
  }
  .css {
    margin: .08rem auto 0;
    border: .01rem solid #EAEAEA;
    border-radius: .06rem;
    text-align: center;
    width: 70%;
    min-height: 0.18rem;
    font-family: PingFangSC-Regular;
    font-size: 0.14rem;
    /*color: #666;*/
    background: white;
    color: red;
    letter-spacing: 0;
    padding: .1rem;
    position: fixed;
    top: 3.8rem;
    left: 12%;
    z-index: 111;
    /*margin-top: -0.27rem;*/
  }

</style>
