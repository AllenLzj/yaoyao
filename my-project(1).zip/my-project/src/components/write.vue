<template>
  <div class="write">
    <div class="top">
      <img src="../../static/img/icon_fanhui_daohang@2x.png" alt="" @click="back">
      <span>分享文章</span>
    </div>

    <div class="content">
      <div>标题</div>
      <input type="text" placeholder="请输入文章标题" v-model="title">
      <div>类别</div>
      <select v-model="type">
        <option value="1">自习</option>
        <option value="2">体育活动</option>
        <option value="3">社团活动</option>
        <option value="4">课外休闲</option>
      </select>
      <br>
      <div>内容</div>
      <textarea name="" id="111" cols="30" rows="10" placeholder="请输入文章内容" v-model="info"></textarea>
    </div>
    <div class="sub" @click="sub">
      分享
    </div>
  </div>
</template>

<script>
  export default {
    name: "write",
    data() {
      return {
        info: "",
        title: "",
        type: 1
      }
    },
    mounted() {
      var arr=[]
      function fun() {
        for (var i=1;i<=4;i++){
          var n=""
          for (var j=1;j<=10;j++){
            var s=parseInt(Math.random()*11)
            n=n+s
          }
          arr.push(n)
        }
        return arr
      }
      console.log(fun())
      var thats = this
      if (api.deviceId) {
        api.addEventListener({
          name: 'keyback'
        }, function (ret, err) {
          thats.$router.go(-1)
        })
      }
    },
    methods: {
      back() {
        this.$router.go(-1)
      },
      sub() {
        if(this.info!=""&&this.title!=""){
          this.$http.get(this.$store.state.url + "/V1/article_add", {
            params: {
              user_id: this.$cookieStore.getCookie("user_id"),
              title: this.title,
              info: this.info,
              type:this.type
            }
          }).then(res => {
            console.log(res)
            this.$store.state.arr = [].concat([false, false, false, false, true])
            this.$router.push("/share")
          })
        }

      }
    }
  }
</script>

<style scoped>
  .write {
    padding-top: .6rem;
  }

  .top {
    height: .5rem;
    width: 100%;
    background: #00B2F0;
    line-height: .5rem;
    color: white;
    font-size: .16rem;
    font-weight: 700;
    position: fixed;
    top: 0;
    left: 0;
  }

  .top img {
    width: .1rem;
    position: absolute;
    top: 30%;
    left: .2rem;
  }

  .content {
    text-align: left;
    padding: 0 .2rem;

  }

  .content div {
    margin: .1rem 0;
    font-weight: 700;
    font-size: .18rem;
  }

  .content input {
    width: 90%;
    padding: .1rem;
  }

  .content textarea {
    width: 90%;
    padding: .1rem;
  }

  .sub {
    height: .4rem;
    width: 100vw;
    text-align: center;
    line-height: .4rem;
    color: white;
    background: #007aff;
    font-size: .16rem;
    position: fixed;
    bottom: 0;
    left: 0;
  }
  select{
    padding: .08rem;
  }

</style>

