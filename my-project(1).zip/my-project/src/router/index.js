import Vue from 'vue'
import Router from 'vue-router'
import index from '@/components/index'
import page from '@/components/page'
import study from '@/components/study'
import free from '@/components/free'
import active from '@/components/active'
import share from '@/components/share'
import self from '@/components/self'
import edit from '@/components/edit'
import friend from '@/components/friend'
import login from '@/components/login'
import register from '@/components/register'
import reset from '@/components/reset'
import release from '@/components/release'
import my_release from '@/components/my_release'
import run from '@/components/run'
import my_join from '@/components/my_join'
import article from '@/components/article'
import write from '@/components/write'
import yan from '@/components/yan'
import profile_picture from '@/components/profile_picture'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: index,
      children: [{
        path: '/',
        name: 'page',
        component: page,
        children: [
          {
            path: "/",
            name: "study",
            component: study
          },
          {
            path:"/run",
            name:"run",
            component:run
          },
          {
            path:"/active",
            name:"active",
            component:active
          },{
            path:"/free",
            name:"free",
            component:free
          }
        ]
      }, {
        path: '/share',
        name: 'share',
        component: share,
      }, {
        path: '/self',
        name: 'self',
        component: self,
      }, {
        path: '/friend',
        name: 'friend',
        component: friend
      }
        , {
          path: '/release',
          name: 'release',
          component: release
        }
      ]
    },
    {
      path: '/login',
      name: 'login',
      component: login,
    },
    {
      path: '/register',
      name: 'register',
      component: register,
    },
    {
      path: '/reset',
      name: 'reset',
      component: reset,
    },
    {
      path: '/edit',
      name: 'edit',
      component: edit,
    },
    {
      path: '/my_release',
      name: 'my_release',
      component: my_release,
    },
    {
      path: '/my_join',
      name: 'my_join',
      component: my_join,
    },
    {
      path: '/article',
      name: 'article',
      component: article,
    },
    {
      path: '/write',
      name: 'write',
      component: write,
    },
    {
      path: '/yan',
      name: 'yan',
      component: yan,
    },
    {
      path: '/profile_picture',
      name: 'profile_picture',
      component: profile_picture,
    }
  ]

})
