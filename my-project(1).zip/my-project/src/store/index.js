import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);
const state={
  arr:[true,false,false,false,false],
  count:0,
  url:""
}
const store = new Vuex.Store({state});

export default store;
